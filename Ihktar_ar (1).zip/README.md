
  # Ihktar/ar

  This is a code bundle for Ihktar/ar. The original project is available at https://www.figma.com/design/GlHgMjTZu8MREheYzG5LHb/Ihktar-ar.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  